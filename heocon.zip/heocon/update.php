<?php
include 'connect.php';
if(isset($_POST['update'])){
    $id=$_GET['id'];
    $name=$_POST['name'];
    $mota=$_POST['mota'];
    $anh=$_POST['anh'];
    
    $db->exec("update show_baiviet set name='$name',mota='$mota',anh='$anh'");
    header("location:index.php");
}
?>

<html>
    <head>
        <title>create</title>
    </head>
    <body>
        <?php
            $id=$_GET['id'];
            $sql="select * from show_baiviet where id='$id'";
            $result=$db->query($sql);
            foreach ($result as $row){
                
            }
        ?>
        <form method="post"><input type="hidden" name="update">
            <table>
                <tr>
                    <td>tensp</td>
                    <td><input type="text" name="name" value="<?php echo $row[1]?>"></td>
                </tr>
                <tr>
                    <td>mota</td>
                    <td><input type="text" name="mota" value="<?php echo $row[2]?>"></td>
                </tr>
                <tr>
                    <td>anh</td>
                    <td><input type="text" name="anh" value="<?php echo $row[3]?>"></td>
                </tr>
                <tr>
                    
                    <td><button>update</button></td>
                </tr>
            </table>  
        </form>
    </body>
</html>

