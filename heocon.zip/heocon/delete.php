<?php
include 'connect.php';
$id=$_GET['id'];
$db->exec("delete from show_baiviet where id='$id'");
header("location:index.php");
