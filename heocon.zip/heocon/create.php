<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $mota=$_POST['mota'];
    $anh=$_POST['anh'];
    
    $db->exec("insert into show_baiviet (name,mota,anh)value('$name','$mota','$anh')");
    header("location:index.php");
}
?>

<html>
    <head>
        <title>create</title>
    </head>
    <body>
        <form method="post"><input type="hidden" name="submit">
            <table>
                <tr>
                    <td>tensp</td>
                    <td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td>mota</td>
                    <td><input type="text" name="mota"></td>
                </tr>
                <tr>
                    <td>anh</td>
                    <td><input type="text" name="anh"></td>
                </tr>
                <tr>
                    
                    <td><button>submit</button></td>
                </tr>
            </table>  
        </form>
    </body>
</html>

