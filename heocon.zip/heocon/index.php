<?php include 'connect.php';
$show_baiviet=$db->query("select * from show_baiviet");
?>
<html>
    <head>
        <title>title</title>
        <link href="css.css" rel="stylesheet" type="text/css"/>
        <script type="text/javascript">
           var mang=[];
           mang[0]="hinh1.jpg";
           mang[1]="hinh2.jpg";
           mang[2]="hinh3.jpg";
           mang[3]="hinh4.jpg";
           var i=0;
           function slide(){
               i=i+1;
               document.images['anh'].src=mang[i];
               if(i==mang.length-1)
                   i=-1;
               setTimeout("slide()",2000);
           }
           window.onload=function(){
              setTimeout("slide()",2000); 
           }
           
        </script>
            
   <body>

    <body>

        <header>
            <div class="header_left">logoff</div>
            <div class="header_right">
                <ul>
                    <li><a href="#">trang chu</a></li>
                    <li><a href="#">trang chu</a></li>
                    <li><a href="#">trang chu</a></li>
                    <li> <a href="#">trang chu</a></li>
                    <li> <a href="login.php">DANG NHAP</a></li>
                    
                </ul>
            </div>
        </header>
        <section>
            <div class="conten_left">
                <?php
                foreach ($show_baiviet as $show_baiviets){
                ?>
                <h3 style="text-align: center; font-size: 30px;">noi dung</h3>
                <article>
                    <figure><img align="left" src="<?php echo $show_baiviets['anh']?>" width="150"></figure> 
                    <h3><?php echo $show_baiviets['name']?></h3>
                      <p><?php echo $show_baiviets['mota']?></p>
                      <a href="delete.php?id=<?php echo $show_baiviets['id']?>">xoa </a>
                      <a href="update.php?id=<?php echo $show_baiviets['id']?>">sua </a>
                </article>
                <?php }?>
                <a href="create.php"><h4 style="font-size: 24px;">them</h4> </a>
            </div>
            <div class="conten_right">
                <img src="hinh1.jpg" name="anh" width="300px" height="300px" style="border:1px solid #d9ba77; border-radius:10px; margin-top: 20px; margin-left: 15px;"
                
            </div>
        </section>
        <footer>ff</footer>
    </body>
</html>


