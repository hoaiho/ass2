<?php
$db= new pdo('mysql:host=localhost;dbname=demo2','root','');