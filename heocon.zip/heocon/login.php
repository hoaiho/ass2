<html>
    <head>
        <title>login</title>
    </head>
    <body>
        <form method="post" action="dangnhap.php">
            <table>
                <tr>
                    <td>username</td>
                    <td><input type="text" name="username"></td>
                </tr>
                 <tr>
                    <td>password</td>
                    <td><input type="password" name="password"></td>
                </tr>
                 <tr>
                   
                    <td><input type="submit" name="dangnhap"></td>
                </tr>
            </table>
        </form>
    </body>
</html>

