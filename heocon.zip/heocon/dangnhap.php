<?php
include 'connect.php';
$username=$_POST['username'];
$password=md5($_POST['password']);

$sql="select * from user where username='$username' and password='$password'";
$result=$db->query($sql);
$kq=$result->rowcount();
if($kq==1){
    echo 'dang nhap thanh cong';
    include 'index.php';
}else{
    echo 'dang nhap khoong thanh cong';
}
